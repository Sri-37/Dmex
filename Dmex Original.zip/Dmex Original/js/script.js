


const cursor = document.getElementById('customCursor');

document.addEventListener('mousemove', (e) => {
  cursor.style.top = `${e.clientY}px`;
  cursor.style.left = `${e.clientX}px`;
});








    document.addEventListener('DOMContentLoaded', () => {
      const menu = document.querySelector('.menu');
      const menuList = document.querySelector('nav ul');
  
      menu.addEventListener('click', () => {
        menuList.classList.toggle('showmenu');
      });
    });




    const counters = document.querySelectorAll('.number');
let started = false;

function animateCounters() {
  if (!started && isInViewport(document.getElementById('counters'))) {
    counters.forEach(counter => {
      const target = +counter.getAttribute('data-target');
      let count = 0;
      const increment = target / 200;

      const updateCount = () => {
        count += increment;
        if (count < target) {
          counter.innerText = Math.ceil(count);
          requestAnimationFrame(updateCount);
        } else {
          counter.innerText = target + '+';  // ← add '+' here
        }
      };

      updateCount();
    });

    started = true;
  }
}

function isInViewport(el) {
  const rect = el.getBoundingClientRect();
  return rect.top <= (window.innerHeight || document.documentElement.clientHeight);
}

window.addEventListener('scroll', animateCounters);





  // Show the sidebar
  document.querySelector('.contact-us-link').addEventListener('click', function (e) {
    e.preventDefault();
    document.getElementById('contactSidebar').style.width = '300px'; // match your sidebar-content width
  });

  // Hide the sidebar
  document.getElementById('closeBtn').addEventListener('click', function () {
    document.getElementById('contactSidebar').style.width = '0';
  });









const leftArrow = document.querySelector('.leftarrow img');
const rightArrow = document.querySelector('.rightarrow img');
const test1 = document.querySelector('.test1');

let slidePosition = 0;
const slideDistance = 300;

function slideLeft() {
  if (slidePosition < 0) {
    slidePosition += slideDistance;
    test1.style.transform = `translateX(${slidePosition}px)`;
  }
}

function slideRight() {
  const maxSlide = -(test1.scrollWidth - test1.offsetWidth);
  if (slidePosition > maxSlide) {
    slidePosition -= slideDistance;
    test1.style.transform = `translateX(${slidePosition}px)`;
  }
}

leftArrow.addEventListener('click', slideLeft);
rightArrow.addEventListener('click', slideRight);








  let currentIndex = 0;
  const totalItems = 6;
  const visibleItems = 3; // how many are shown at once
  const itemWidth = 60; // 40px image + 20px gap

  function updateSlider() {
    const slider = document.getElementById("slider");
    const maxIndex = totalItems - visibleItems;
    const shift = Math.min(currentIndex, maxIndex) * itemWidth;
    slider.style.transform = `translateX(-${shift}px)`;
  }

  function next() {
    if (currentIndex < totalItems - visibleItems) {
      currentIndex++;
      updateSlider();
    }
  }

  function prev() {
    if (currentIndex > 0) {
      currentIndex--;
      updateSlider();
    }
  }